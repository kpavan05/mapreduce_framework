/*
 *
 * Copyright 2015 gRPC authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <iostream>
#include <memory>
#include <string>

#include <chrono>
#include <thread>

#include <conservator/ConservatorFrameworkFactory.h>
#include <zookeeper/zookeeper.h>
#include <grpcpp/grpcpp.h>

#include "sample.grpc.pb.h"
//#include <uuid/uuid.h>

using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;
using helloworld::Greeter;
using helloworld::HelloReply;
using helloworld::HelloRequest;

class GreeterClient {
 public:
  GreeterClient(std::shared_ptr<Channel> channel)
      : stub_(Greeter::NewStub(channel)) {}

  // Assembles the client's payload, sends it and presents the response back
  // from the server.
  std::string SayHello(const std::string& user) {
    // Data we are sending to the server.
    HelloRequest request;
    request.set_name(user);

    // Container for the data we expect from the server.
    HelloReply reply;

    // Context for the client. It could be used to convey extra information to
    // the server and/or tweak certain RPC behaviors.
    ClientContext context;

    // The actual RPC.
    Status status = stub_->SayHello(&context, request, &reply);

    // Act upon its status.
    if (status.ok()) {
      return reply.message();
    } else {
      std::cout << status.error_code() << ": " << status.error_message()
                << std::endl;
      return "RPC failed";
    }
  }

 private:
  std::unique_ptr<Greeter::Stub> stub_;
};

int main(int argc, char** argv) {
  // Instantiate the client. It requires a channel, out of which the actual RPCs
  // are created. This channel models a connection to an endpoint specified by
  // the argument "--target=" which is the only expected argument.
  // We indicate that the channel isn't authenticated (use of
  // InsecureChannelCredentials()).

  /*
  std::string target_str;
  std::string arg_str("--target");
  if (argc > 1) {
    std::string arg_val = argv[1];
    size_t start_pos = arg_val.find(arg_str);
    if (start_pos != std::string::npos) {
      start_pos += arg_str.size();
      if (arg_val[start_pos] == '=') {
        target_str = arg_val.substr(start_pos + 1);
      } else {
        std::cout << "The only correct argument syntax is --target="
                  << std::endl;
        return 0;
      }
    } else {
      std::cout << "The only acceptable argument is --target=" << std::endl;
      return 0;
    }
  } else {
    target_str = "localhost:50051";
  }
  
  uuid_t id;
  uuid_generate(id);
  char *gid = new char[100];
  uuid_unparse(id, sid);
  std::string sid(gid);
    
  std::string nodeGuid = framework->getData().forPath(nodeName);
  if (nodeGuid.compare(sid) == 0) { std::cout<<"I am the leader and my id is " << nodeName <<std::endl; }
  else { while(true) { } }

  */

  //Create factory for framework
  ConservatorFrameworkFactory factory = ConservatorFrameworkFactory();
  //Create a new connection object to Zookeeper
  unique_ptr<ConservatorFramework> framework = factory.newClient("localhost:2181",10000000);
  //Start the connection
  framework->start();
  
  framework->create()->forPath("/masters");
  framework->create()->withFlags(ZOO_SEQUENCE|ZOO_EPHEMERAL)->forPath("/masters/master_");
  
  std::vector<string> children = framework->getChildren()->forPath("/masters");
  std::cout<< "number of children " << children.size() << std::endl;
  if (children.size() == 1) 
  {
    std::cout << " I am the leader" <<std::endl;
  }
  else
  {
    std::sort(children.begin(), children.end());
    std::string curLeader = "/masters/" + children.at(0);


    std::cout<<"I am not the leader, stay put" << std::endl;

    while ( framework->checkExists()->forPath(curLeader) == ZOK)
    {
      std::this_thread::sleep_for(std::chrono::milliseconds(1000));

    }
    std::cout<<"Original Leader failed and I am the leader" << std::endl;
  }

  vector<string> wrkrs = framework->getChildren()->forPath("/workers");
  std::string wrkPath = "/workers/" + wrkrs.at(0);
  std::cout <<"worker path " << wrkPath << std::endl;

  std::string target_str = framework->getData()->forPath("/workers/worker1") + ":50051";
  std::cout <<"ip address of worker" << target_str << std::endl;
  if (target_str.empty()) 
  {
    std::cout << " cannot retrieve ip address of worker " << std::endl;
  }

  GreeterClient greeter(grpc::CreateChannel(target_str, grpc::InsecureChannelCredentials()));
  std::string user("hello ");

  while (true) {
  std::string reply = greeter.SayHello(user);
  std::cout << "Greeter received: " << reply << std::endl;
  }

  return 0;
}
