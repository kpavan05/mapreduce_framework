# Prerequisites
Have the Conservator library installed previously, e.g. make install

#Compilation process
cmake .
make 

#Binary location
build/example
